<template>
<div class="hero-head">
            <nav class="navbar">
                <div class="container">
                    <div class="navbar-brand">
                       <span class="navbar-item">
                            <router-link to="/" class="is-white is-outlined">
                                    <h1 class="title is-2">Super Hero</h1>
                            </router-link>
                            </span>
                        <span class="navbar-burger burger" data-target="navbarMenu">
                            <span></span>
                            <span></span>
                            <span></span>
                        </span>
                    </div>
                    <div id="navbarMenu" class="navbar-menu">
                        <div class="navbar-end">
                            <span class="navbar-item">
                            <router-link to="/" class="button is-white is-outlined">
                                    <span class="icon">
                                        <i class="fa fa-home"></i>
                                    </span>
                                    <span>DashBoard</span>
                            </router-link>
                            </span>
                            <span class="navbar-item">
                                <router-link to="/Search" class="button is-white is-outlined">
                                    <span class="icon">
                                        <i class="fas fa-search"></i>
                                    </span>
                                    <span>Find superhero</span>
                                </router-link>
                            </span>
                            <span class="navbar-item">
                                <a class="button is-white is-outlined" target="_blank" href="https://github.com/muthukumaran-m/super-heroes">
                                    <span class="icon">
                                        <i class="fab fa-github"></i>
                                    </span>
                                    <span>View Source</span>
                                </a>
                            </span>
                        </div>
                    </div>
                </div>
            </nav>
            </div>
</template>
<style scoped>

</style>