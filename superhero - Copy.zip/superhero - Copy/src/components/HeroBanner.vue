<template>
  <div class="section">
    <div class="box searchbox">
      <div class="field has-addons">
        <div class="control is-expanded">
          <input
            v-model="searchhero"
            class="input has-text-centered"
            type="search"
            @keyup.enter="getData"
            placeholder="» » » » » » find super hero « « « « « «"
          />
        </div>
        <div class="control">
          <a class="button is-info" v-bind:class="{'is-loading':loading}" @click="getData">Search</a>
        </div>
      </div>
    </div>
    <progress v-if="loading" class="progress is-large is-primary card" max="100">60%</progress>
    <div v-if="!loading">
      <span class="tag is-light is-large" v-if="heroSearch.data.error">{{heroSearch.data.error}}</span>
      <router-link
        :to="{name:'Hero',params:{id:hero.id}}"
        class="box card"
        v-for="hero in heroSearch.data.results"
        v-bind:key="hero.id"
      >
        <article class="media">
          <div class="media-left">
            <figure class="image is-64x64">
              <img v-bind:src="hero.image.url" alt="Image" />
            </figure>
          </div>
          <div class="media-content">
            <div class="content">
              <p>
                <strong>{{hero.biography['full-name']}}</strong>
                <small>@{{hero.biography.aliases[0]}}</small>
                <br />
                {{hero.biography['alter-egos']}}
                <span v-if="hero.biography.aliases[0]!='-'">
                  Has different names like
                  <span
                    v-for=" (name,idx) in hero.biography.aliases"
                    v-bind:key="idx"
                  >
                    {{name}}
                    <span v-if="idx+1!=hero.biography.aliases.length">,</span>
                  </span>
                  .
                </span>
                <span
                  v-if="hero.biography['first-appearance']!='-'"
                >His first appearance is {{hero.biography['first-appearance']}} .</span>
                {{hero.biography.publisher}} is the publisher of this creature. This super hero has a alignment of {{hero.biography.alignment}}.
              </p>
            </div>
          </div>
        </article>
      </router-link>
    </div>
  </div>
</template>

<style scoped>
</style>

<script>
import axios from "axios";
export default {
  name: "HeroBanner",
  data() {
    return {
      searchhero: "",
      heroSearch: { data: { results: "" } },
      loading: false
    };
  },
  methods: {
    getData() {
      this.loading = true;
      axios
        .get(
          "https://cors-anywhere.herokuapp.com/https://superheroapi.com/api/163220391589190/search/" +
            this.searchhero
        )
        .then(response => {
          this.loading = false;
          this.heroSearch = response;
        });
    }
  }
};
</script>