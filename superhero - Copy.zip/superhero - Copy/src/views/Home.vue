<template>
  <div class="hero-body">
    <GChart class="container" type="ScatterChart" :data="chartData" :options="chartOptions" />
  </div>
</template>
<style scoped>
.hero-body {
  background-color:aliceblue;
}
</style>
<script>
// @ is an alias to /src
import { GChart } from "vue-google-charts";
export default {
  name: "home",
  data() {
    return {
      // Array will be automatically processed with visualization.arrayToDataTable function
      chartData: [
        [
          "Powerstats",
          "Intelligence",
          "Strength",
          "Speed",
          "Durability",
          "Power",
          "Combat"
        ],
        ["Batman", 81, 40, 29, 55, 63, 90],
        ["Spider-Man", 90, 55, 67, 75, 74, 85],
        ["Iron Man", 100, 85, 58, 85, 100, 64],
        ["Superman", 94, 100, 100, 100, 100, 85],
        ["Wolverine", 63, 32, 50, 100, 89, 100],
        ["Captain America", 69, 19, 38, 55, 60, 100],
        ["Hulk", 88, 100, 63, 100, 98, 85],
        ["Thor", 69, 100, 83, 100, 100, 100],
        ["Flash", 63, 10, 100, 50, 68, 32],
        ["Thanos", 100, 100, 33, 100, 100, 80],
        ["Ant-Man", 100, 18, 23, 28, 32, 32],
        ["Aquaman", 81, 85, 79, 80, 100, 80],
        ["Wonder Woman", 88, 100, 79, 100, 100, 100],
        ["Wonder Girl", 75, 90, 25, 80, 39, 60],
        ["Captain Marvel", 88, 100, 88, 95, 100, 75],
        ["Ultron", 88, 83, 42, 100, 100, 64],
        ["Groot", 75, 85, 33, 70, 100, 64]
      ],
      chartOptions: {
        title: "PowerStats of famous heroes - Data by Superhero API",
        width: 1100,
        height: 500,
        backgroundColor: { fill: "transparent" },
        is3D: true,
        animation: {
          startup:true,
          duration: 5000,
          easing: "out"
        },
        vAxis: {minValue:0, maxValue:100}
      }
    };
  },
  components: {
    GChart
  }
};
</script>
