<template>
  <div class="hero section">
    <progress v-if="loading" class="progress is-large is-primary card" max="100">60%</progress>
    <div v-if="!loading" class="columns">
      <div class="column is-one-third">
        <div class="card">
          <div class="card-image">
            <figure class="image is-4by3">
              <img v-bind:src="heroInfo.data.image.url" alt="Placeholder image" />
            </figure>
          </div>
          <div class="card-content">
            <div class="media">
              <div class="media-left">
                <figure class="image is-48x48">
                  <img v-bind:src="heroInfo.data.image.url" alt="Placeholder image" />
                </figure>
              </div>
              <div class="media-content">
                <p
                  class="title is-4 has-text-black"
                  v-if="heroInfo.data.biography['full-name']"
                >{{heroInfo.data.biography['full-name']}}</p>
                <p class="title is-4 has-text-black">@No Name</p>
                <p
                  class="subtitle is-6 has-text-black is-paddingless"
                >{{heroInfo.data.biography['place-of-birth']}}</p>
              </div>
            </div>

            <div class="content biography">
              {{heroInfo.data.biography['alter-egos']}}
              <span
                v-if="heroInfo.data.biography.aliases[0]!='-'"
              >
                Has different names like
                <span
                  v-for=" (name,idx) in heroInfo.data.biography.aliases"
                  v-bind:key="idx"
                >
                  {{name}}
                  <span v-if="idx+1!=heroInfo.data.biography.aliases.length">,</span>
                </span>.
              </span>
              <span
                v-if="heroInfo.data.biography['first-appearance']!='-'"
              >His first appearance is {{heroInfo.data.biography['first-appearance']}} .</span>
              {{heroInfo.data.biography.publisher}} is the publisher of this creature. This super hero has a alignment of {{heroInfo.data.biography.alignment}}.
            </div>
          </div>
        </div>
      </div>
      <div class="column">
        <div class="columns">
          <div class="column">
            <article class="message is-danger">
              <div class="message-header">
                <p>Powerstats</p>
              </div>
              <div class="message-body has-text-left">
                <p>
                  <strong>Intelligence</strong>
                  : {{heroInfo.data.powerstats.intelligence}}
                </p>
                <p>
                  <strong>Strength</strong>
                  : {{heroInfo.data.powerstats.strength}}
                </p>
                <p>
                  <strong>Speed</strong>
                  : {{heroInfo.data.powerstats.speed}}
                </p>
                <p>
                  <strong>Durability</strong>
                  : {{heroInfo.data.powerstats.durability}}
                </p>
                <p>
                  <strong>Power</strong>
                  : {{heroInfo.data.powerstats.power}}
                </p>
                <p>
                  <strong>Combat</strong>
                  : {{heroInfo.data.powerstats.combat}}
                </p>
              </div>
            </article>
          </div>

          <div class="column">
            <article class="message is-primary">
              <div class="message-header">
                <p>Appearance</p>
              </div>
              <div class="message-body has-text-left">
                <p>
                  <strong>Gender</strong>
                  : {{heroInfo.data.appearance.gender}}
                </p>
                <p>
                  <strong>Race</strong>
                  : {{heroInfo.data.appearance.race}}
                </p>
                <p>
                  <strong>Height</strong>
                  :{{heroInfo.data.appearance.height[0]}} | {{heroInfo.data.appearance.height[1]}}
                </p>
                <p>
                  <strong>Weight</strong>
                  : {{heroInfo.data.appearance.weight[0]}} | {{heroInfo.data.appearance.weight[1]}}
                </p>
                <p>
                  <strong>Eye-color</strong>
                  : {{heroInfo.data.appearance['eye-color']}}
                </p>
                <p>
                  <strong>Hair-color</strong>
                  : {{heroInfo.data.appearance['hair-color']}}
                </p>
              </div>
            </article>
          </div>
        </div>
        <div class="columns">
          <div class="column">
            <article class="message is-info">
              <div class="message-header">
                <p>Work</p>
              </div>
              <div class="message-body has-text-left">
                <p>
                  <strong>Occupation</strong>
                  : {{heroInfo.data.work.occupation}}
                </p>
                <p>
                  <strong>Base</strong>
                  : {{heroInfo.data.work.base}}
                </p>
              </div>
            </article>
          </div>

          <div class="column">
            <article class="message is-success">
              <div class="message-header">
                <p>Connections</p>
              </div>
              <div class="message-body has-text-left">
                <p>
                  <strong>Group-affiliation</strong>
                  : {{heroInfo.data.connections['group-affiliation']}}
                </p>
                <p>
                  <strong>Relatives</strong>
                  : {{heroInfo.data.connections.relatives}}
                </p>
              </div>
            </article>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
// @ is an alias to /src
import axios from "axios";
export default {
  name: "hero",
  components: {},
  data() {
    return {
      heroInfo: null,
      loading:true
    };
  },
  props: ["id"],
  mounted() {
    axios
      .get(
        "https://cors-anywhere.herokuapp.com/https://superheroapi.com/api/163220391589190/" + this.$route.params.id,
        { useCredentails: true }
      )
      .then(response =>{
        this.loading=false
        this.heroInfo = response});
  }
};
</script>
