<template>
  <div id="app">
    <section class="hero is-info is-fullheight">
      <Nav/>
    <router-view/>
    </section>
  </div>
</template>

<style lang="scss">
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}

#nav {
  padding: 30px;

  a {
    font-weight: bold;
    color: #2c3e50;

    &.router-link-exact-active {
      color: #42b983;
    }
  }
}
html,
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif;
        }
        
        .hero.is-info {
            background: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url('https://unsplash.it/1200/900?random') no-repeat center center fixed;
            -webkit-background-size: cover;
            -moz-background-size: cover;
            -o-background-size: cover;
            background-size: cover;
        }
        
        .hero .nav,
        .hero.is-success .nav {
            -webkit-box-shadow: none;
            box-shadow: none;
        }
        
        .hero .subtitle {
            padding: 3rem 0;
            line-height: 1.5;
        }
</style>
<script>
import Nav from '@/components/Nav.vue'
export default {
  name:'app',
  components:{
    Nav
  }
}
</script>