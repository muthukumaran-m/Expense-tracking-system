module.exports = {
    publicPath: process.env.NODE_ENV === 'production' ? '/super-heroes' : '/',
    devServer: {
        proxy: 'https://superheroapi.com/',
    }
}